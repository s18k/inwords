
<h1 align="center"> Inwords </h1>


<h2 align="center"> A Python package to spell out numbers </h2>


<h3 align="center"> How to Run</h3>
<h3> Installation </h3>
pip install inwords

<h3>Open Python console and run the following commands</h3>
